const linksList = document.getElementById("links-list");
const addBtn = document.getElementById("add-link");
const titleInput = document.getElementById("link-title");
const urlInput = document.getElementById("link-url");
const ratioDisplay = document.getElementById("link-ratio");
// const darkBtn = document.getElementById("dark-mode");
const toggleBtn = document.getElementById("dark-mode");


const MAX_LINKS = 10;

// Default links
const defaultLinks = [
  {title: "Google", url: "https://google.com"},
  {title: "YouTube", url: "https://youtube.com"},
  {title: "Wikipedia", url: "https://wikipedia.org"},
  {title: "Gmail", url: "https://mail.google.com"},
  {title: "Twitter", url: "https://twitter.com"}
];

// Initialize storage
chrome.storage.sync.get(["links"], (result) => {
  if(!result.links) {
    chrome.storage.sync.set({links: defaultLinks});
    renderLinks(defaultLinks);
  } else {
    renderLinks(result.links);
  }
});

// Render links function
function renderLinks(links){
  linksList.innerHTML = "";
  links.forEach((link,index)=>{
    const li = document.createElement("li");
    li.innerHTML = `<a href="${link.url}" target="_blank">${link.title}</a>
                    <div>
                      <button class="edit-btn" data-index="${index}">Edit</button>
                      <button class="delete-btn" data-index="${index}">Del</button>
                    </div>`;
    linksList.appendChild(li);
  });

  // Update ratio
  ratioDisplay.innerText = `Links: ${links.length}/${MAX_LINKS} used`;

  // Delete functionality
  document.querySelectorAll(".delete-btn").forEach(btn=>{
    btn.addEventListener("click",(e)=>{
      const i = e.target.dataset.index;
      links.splice(i,1);
      chrome.storage.sync.set({links});
      renderLinks(links);
    });
  });

  // Edit functionality
  document.querySelectorAll(".edit-btn").forEach(btn=>{
    btn.addEventListener("click",(e)=>{
      const i = e.target.dataset.index;
      const newTitle = prompt("Enter new title", links[i].title);
      const newUrl = prompt("Enter new URL", links[i].url);
      if(newTitle && newUrl){
        links[i].title = newTitle;
        links[i].url = newUrl;
        chrome.storage.sync.set({links});
        renderLinks(links);
      }
    });
  });

  chrome.storage.sync.set({links});
}

// Add new link
addBtn.addEventListener("click",()=>{
  const title = titleInput.value.trim();
  const url = urlInput.value.trim();
  if(!title || !url) return alert("Fill both fields");

  chrome.storage.sync.get(["links"],(result)=>{
    const links = result.links || [];
    if(links.length>=MAX_LINKS) return alert("Maximum links reached");
    links.push({title,url});
    chrome.storage.sync.set({links});
    renderLinks(links);
    titleInput.value = "";
    urlInput.value = "";
  });
});



// Load saved theme
chrome.storage.sync.get(["darkMode"], (result) => {
  if (result.darkMode) {
    document.body.classList.add("dark-mode");
    toggleBtn.textContent = "Light";
  } else {
    toggleBtn.textContent = "Dark";
  }
});

// Toggle on click
toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  if (document.body.classList.contains("dark-mode")) {
    toggleBtn.textContent = "Light";
    chrome.storage.sync.set({darkMode: true});
  } else {
    toggleBtn.textContent = "Dark";
    chrome.storage.sync.set({darkMode: false});
  }
});
